
#ifndef _EP21R_H_
#define _EP21R_H_

void _ep21R(double * x, double *t, double * u, double * v, int n, int k);

#endif // _EP21R_H_
